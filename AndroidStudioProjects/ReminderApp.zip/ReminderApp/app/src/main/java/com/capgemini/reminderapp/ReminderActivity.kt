package com.capgemini.reminderapp

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_reminder.*
import java.util.*

val MY_BROADCAST_SCHEDULE_ACTION  = "com.capgemini.androidreceiver.action.scheduled"
var titleV:String = ""
var timeV:String=""
var dateV:String=""
var desV:String=""
class ReminderActivity : AppCompatActivity() ,
    DatePickerDialog.OnDateSetListener,
    TimePickerDialog.OnTimeSetListener
{
    val myReceiver=LocalReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder)

        val filter = IntentFilter(MY_BROADCAST_SCHEDULE_ACTION)
        registerReceiver(myReceiver,filter)

        val int = intent
        if(int.getStringExtra("callingactivity")=="listrem") {
            var titleRem = int.getStringExtra("titleEdit")
            var desRem = int.getStringExtra("desEdit")
            var dateRem = int.getStringExtra("dateEdit")
            var timeRem = int.getStringExtra("timeEdit")
            Toast.makeText(this,"titleEdit:$titleRem desEdit: $desRem dateEdit: $dateRem timeEdit:$timeRem",Toast.LENGTH_LONG).show()
            val titleEdit: TextView = findViewById<TextView>(R.id.titleE)
            val desEdit: TextView = findViewById<TextView>(R.id.desE)
            val dateEdit: TextView = findViewById<TextView>(R.id.dateE)
            val timeEdited: TextView = findViewById(R.id.timeE) as TextView
            timeEdited.text=timeRem
            titleEdit.text = titleRem
            desEdit.text = desRem
            dateEdit.text = dateRem

        }
    }


    fun clickAddReminder(view: View){
        var intent:Intent = Intent(this,RemainderView::class.java)

        titleV=titleE.text.toString()
        desV=desE.text.toString()
        dateV=dateE.text.toString()
        timeV=timeE.text.toString()

        if(titleV.isNotEmpty() && desV.isNotEmpty() && dateV.isNotEmpty() && timeV.isNotEmpty()){
            intent.putExtra("title",titleV)
            intent.putExtra("des",desV)
            intent.putExtra("date",dateV)
            intent.putExtra("time",timeV)

            startActivity(intent)
            Toast.makeText(this,"Reminder Set",Toast.LENGTH_SHORT).show()
            sendNotification(0)
            finish()
            var timeSetting = timeV.split(':')
            when(view.id){
                R.id.addRemB->{
                    val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
                    val calendar: Calendar = Calendar.getInstance().apply {
                        timeInMillis = System.currentTimeMillis()
                        set(Calendar.HOUR_OF_DAY, timeSetting[0].toInt())
                        set(Calendar.MINUTE,timeSetting[1].toInt())
                    }
                    val bIntent = Intent(MY_BROADCAST_SCHEDULE_ACTION)
                    val pi = PendingIntent.getBroadcast(this,0,bIntent,0)
                    alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis,AlarmManager.INTERVAL_DAY,pi)

                }
            }
        }
        else{
            Toast.makeText(this,"Data incomplete",Toast.LENGTH_SHORT).show()
        }
    }
    fun clickRemCancel(view: View){
        finish()
    }
    fun clickDate(view:View){
        val dlg=MyDialog()
        val bundle = Bundle()
        bundle.putInt("type",1)
        dlg.arguments=bundle
        dlg.show(supportFragmentManager,"aaa")

    }
    fun clickTime(view:View){
        val dlg = MyDialog()
        val bundle  = Bundle()
        bundle.putInt("type", 2)
        dlg.arguments = bundle
        dlg.show(supportFragmentManager, "bbb")
    }

    override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
        val texts: TextView = findViewById(R.id.timeE) as TextView
        val day:String = "$hourOfDay:$minute"
        texts.text=day
    }

    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        val texts: TextView = findViewById(R.id.dateE) as TextView
        val date:String = "$year/${month+1}/$dayOfMonth"
        texts.text=date
    }
    private fun sendNotification(i:Int) {
        val nManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        lateinit var builder: Notification.Builder
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("test", "Reminder",
                NotificationManager.IMPORTANCE_DEFAULT)

            nManager.createNotificationChannel(channel)

            builder = Notification.Builder(this,"test")
        }
        else{
            builder = Notification.Builder(this)
        }


        builder.setSmallIcon(R.drawable.ic_launcher_foreground)
        if(i==0) {
            builder.setContentTitle("Reminder")
            builder.setContentText("New Reminder Added")
        }
        if(i==1){
            builder.setContentTitle(titleV)
            builder.setContentText(desV)
        }
        builder.setAutoCancel(true)

        val intent = Intent(this, RemainderView::class.java)
        val pi = PendingIntent.getActivity(this, 0,intent,0)

        builder.setContentIntent(pi)

        val myNotification = builder.build()

        nManager.notify(1,myNotification)
    }
    inner class LocalReceiver:BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            when(intent?.action){
                MY_BROADCAST_SCHEDULE_ACTION->{
                    Toast.makeText(context,"You received notification",Toast.LENGTH_LONG).show()
                    sendNotification(1)
                }
            }
        }

    }

}